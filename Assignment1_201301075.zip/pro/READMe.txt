Basic controls: up, down, right, left as specified in the assignment document.

Up: Increase the speed of the Top

Down: Decrease the speed of the Top

Right: Increase spin

Left: Decrease spin

Key 't': Change the camera view so that the camera is now placed on the top.

Compile Instructions:

Run the following commands in your terminal.
$ make clean (Removes any existing executables of the same name)
$ make
$ ./shooter 
