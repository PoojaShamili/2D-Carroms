#include <stdio.h>
#include <iostream>
#include <cmath>
#include <fstream>
#include <vector>
#include <GL/glew.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/matrix_transform.hpp>

using namespace std;

struct GLMatrices {
	glm::mat4 projection;
	glm::mat4 model;
	glm::mat4 view;
	GLuint MatrixID;
} Matrices;

GLuint programID;
GLuint VertexArrayID[3];
GLuint vertexbuffer[3];
GLuint colorbuffer[3];
int numVerticesOfTop = 36;
int numVerticesOfCube = 20000;


GLuint LoadShaders(const char * vertex_file_path,const char * fragment_file_path) {

	// Create the shaders
	GLuint VertexShaderID = glCreateShader(GL_VERTEX_SHADER);
	GLuint FragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);

	// Read the Vertex Shader code from the file
	std::string VertexShaderCode;
	std::ifstream VertexShaderStream(vertex_file_path, std::ios::in);
	if(VertexShaderStream.is_open())
	{
		std::string Line = "";
		while(getline(VertexShaderStream, Line))
			VertexShaderCode += "\n" + Line;
		VertexShaderStream.close();
	}

	// Read the Fragment Shader code from the file
	std::string FragmentShaderCode;
	std::ifstream FragmentShaderStream(fragment_file_path, std::ios::in);
	if(FragmentShaderStream.is_open()){
		std::string Line = "";
		while(getline(FragmentShaderStream, Line))
			FragmentShaderCode += "\n" + Line;
		FragmentShaderStream.close();
	}

	GLint Result = GL_FALSE;
	int InfoLogLength;

	// Compile Vertex Shader
	printf("Compiling shader : %s\n", vertex_file_path);
	char const * VertexSourcePointer = VertexShaderCode.c_str();
	glShaderSource(VertexShaderID, 1, &VertexSourcePointer , NULL);
	glCompileShader(VertexShaderID);

	// Check Vertex Shader
	glGetShaderiv(VertexShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(VertexShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	std::vector<char> VertexShaderErrorMessage(InfoLogLength);
	glGetShaderInfoLog(VertexShaderID, InfoLogLength, NULL, &VertexShaderErrorMessage[0]);
	fprintf(stdout, "%s\n", &VertexShaderErrorMessage[0]);

	// Compile Fragment Shader
	printf("Compiling shader : %s\n", fragment_file_path);
	char const * FragmentSourcePointer = FragmentShaderCode.c_str();
	glShaderSource(FragmentShaderID, 1, &FragmentSourcePointer , NULL);
	glCompileShader(FragmentShaderID);

	// Check Fragment Shader
	glGetShaderiv(FragmentShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(FragmentShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	std::vector<char> FragmentShaderErrorMessage(InfoLogLength);
	glGetShaderInfoLog(FragmentShaderID, InfoLogLength, NULL, &FragmentShaderErrorMessage[0]);
	fprintf(stdout, "%s\n", &FragmentShaderErrorMessage[0]);

	// Link the program
	fprintf(stdout, "Linking program\n");
	GLuint ProgramID = glCreateProgram();
	glAttachShader(ProgramID, VertexShaderID);
	glAttachShader(ProgramID, FragmentShaderID);
	glLinkProgram(ProgramID);

	// Check the program
	glGetProgramiv(ProgramID, GL_LINK_STATUS, &Result);
	glGetProgramiv(ProgramID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	std::vector<char> ProgramErrorMessage( max(InfoLogLength, int(1)) );
	glGetProgramInfoLog(ProgramID, InfoLogLength, NULL, &ProgramErrorMessage[0]);
	fprintf(stdout, "%s\n", &ProgramErrorMessage[0]);

	glDeleteShader(VertexShaderID);
	glDeleteShader(FragmentShaderID);

	return ProgramID;
}

float pi = 3.14;
float camera_rotation_angle = 0;
float cube_rotation = 0;
float rectangle_rotation = 0;
float top_position_x = 0;
float top_position_z = 0;
float top_position_y = 0;
float top_velocity_x = 0.05;
float top_velocity_z = 0.05;
float theta = pi/2;

int flag = 0;
int flag1 = 0;
int flag2 = 0;
int view = 0;

void reshapeWindow (int width, int height)
{
	GLfloat fov = 90.0f;
	glViewport (0, 0, (GLsizei) width, (GLsizei) height);
	Matrices.projection = glm::perspective (fov, (GLfloat) width / (GLfloat) height, 0.1f, 500.0f);
}

void createTriangle()
{
	if(flag1 == 1)
	{
	static const GLfloat vertex_buffer_data [] = {
	-1, 0, 0,
	1, 0, 0,
	0, top_position_x, 0	
	};

	static const GLfloat color_buffer_data [] = {
		0, 1, 0,
		0, 1, 0,
		0, 1, 0
	};
	flag1 = 0;
	glBindVertexArray (VertexArrayID[3]); 
	glBindBuffer (GL_ARRAY_BUFFER, vertexbuffer[3]); 
	glBufferData (GL_ARRAY_BUFFER, sizeof(vertex_buffer_data), vertex_buffer_data, GL_STATIC_DRAW); 
	glVertexAttribPointer(
			0,                  
			3,                  
			GL_FLOAT,          
			GL_FALSE,           
			0,                  
			(void*)0            
		);// Bind the VBO colors for pyramid
	glBufferData (GL_ARRAY_BUFFER, sizeof(color_buffer_data), color_buffer_data, GL_STATIC_DRAW); 
	glVertexAttribPointer(
			1,                  // attribute 1. Color
			3,                  // size (r,g,b)
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);
}
	
	if(flag2 == 1)
	{
	static const GLfloat vertex_buffer_data [] = {
	-1, 0, 0,
	1, 0, 0,
	0, 0, top_position_x	
	};

	static const GLfloat color_buffer_data [] = {
		0, 0, 1,
		0, 0, 1,
		0, 0, 1
	};
	flag2 = 0;

	
	glBindVertexArray (VertexArrayID[3]); // Bind the VAO for pyramid
	glBindBuffer (GL_ARRAY_BUFFER, vertexbuffer[3]); // Bind the VBO vertices for pyramid
	glBufferData (GL_ARRAY_BUFFER, sizeof(vertex_buffer_data), vertex_buffer_data, GL_STATIC_DRAW); // Copy the vertices into VBO
	glVertexAttribPointer(
			0,                  // attribute 0. Vertices 
			3,                  // size (x,y,z)
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);
	glBindBuffer (GL_ARRAY_BUFFER, colorbuffer[3]); // Bind the VBO colors for pyramid
	glBufferData (GL_ARRAY_BUFFER, sizeof(color_buffer_data), color_buffer_data, GL_STATIC_DRAW);  // Copy the vertex colors
	glVertexAttribPointer(
			1,                  // attribute 1. Color
			3,                  // size (r,g,b)
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);
}

}

void drawTriangle()
{
	// Bind the VAO to use
	glBindVertexArray (VertexArrayID[3]);

	// Enable Vertex Attribute 0 - 3d Vertices
	glEnableVertexAttribArray(0);
	// Bind the VBO to use
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[3]);

	// Enable Vertex Attribute 1 - Color
	glEnableVertexAttribArray(1);
	// Bind the VBO to use
	glBindBuffer(GL_ARRAY_BUFFER, colorbuffer[3]);

	// Draw the cube !
	glDrawArrays(GL_TRIANGLES, 0, numVerticesOfCube); // Starting from vertex 0
}
float polynomial (float x, float z)
{
	float y = x*x*x - 3*x + z*z*z - 3*z;
	return y;
}

void createTop()
{
	static const GLfloat vertex_buffer_data [] = {
		 0,1, 0, // vertex 0
		-1,0, 1, // vertex 1
		 1,0, 1, // vertex 2

		 0,1, 0, // vertex 0
		 1,0, 1, // vertex 2
		 1,0,-1, // vertex 4

		 0,1, 0, // vertex 0
		 1,0,-1, // vertex 4
		-1,0,-1, // vertex 3
		
		 0,1, 0, // vertex 0
		-1,0,-1, // vertex 3
		-1,0, 1, // vertex 1

		-1,0, 1, // vertex 1
		-1,0,-1, // vertex 3
		 1,0,-1, // vertex 4

		 1,0,-1, // vertex 4
		 1,0, 1, // vertex 2
		-1,0, 1, // vertex 1

		 0,-1, 0, // vertex 5
		-1,0, 1, // vertex 1
		 1,0, 1, // vertex 2

		 0,-1, 0, // vertex 5
		 1,0, 1, // vertex 2
		 1,0,-1, // vertex 4

		 0,-1, 0, // vertex 5
		 1,0,-1, // vertex 4
		-1,0,-1, // vertex 3
		
		 0,-1, 0, // vertex 5
		-1,0,-1, // vertex 3
		-1,0, 1, // vertex 1

		-1,0, 1, // vertex 1
		-1,0,-1, // vertex 3
		 1,0,-1, // vertex 4

		 1,0,-1, // vertex 4
		 1,0, 1, // vertex 2
		-1,0, 1  // vertex 1
	};

	static const GLfloat color_buffer_data [] = {
		1,0,0, // color 0
		0,1,0, // color 1
		0,0,1, // color 2
				
		1,0,0, // color 0
		0,0,1, // color 2
		0,1,1, // color 4
				
		1,0,0, // color 0
		0,1,1, // color 4
		1,1,0, // color 3
				
		1,0,0, // color 0
		1,1,0, // color 3
		0,1,0, // color 1
				
		0,1,0, // color 1
		1,1,0, // color 3
		0,1,1, // color 4
				
		0,1,1, // color 4
		0,0,1, // color 2
		0,1,0,  // color 1

		1,0,0, // color 0
		0,1,0, // color 1
		0,0,1, // color 2
				
		1,0,0, // color 0
		0,0,1, // color 2
		0,1,1, // color 4
				
		1,0,0, // color 0
		0,1,1, // color 4
		1,1,0, // color 3
				
		1,0,0, // color 0
		1,1,0, // color 3
		0,1,0, // color 1
				
		0,1,0, // color 1
		1,1,0, // color 3
		0,1,1, // color 4
				
		0,1,1, // color 4
		0,0,1, // color 2
		0,1,0  // color 1

	};

	glBindVertexArray (VertexArrayID[0]); // Bind the VAO for pyramid
	glBindBuffer (GL_ARRAY_BUFFER, vertexbuffer[0]); // Bind the VBO vertices for pyramid
	glBufferData (GL_ARRAY_BUFFER, sizeof(vertex_buffer_data), vertex_buffer_data, GL_STATIC_DRAW); // Copy the vertices into VBO
	glVertexAttribPointer(
			0,                  // attribute 0. Vertices 
			3,                  // size (x,y,z)
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);
	glBindBuffer (GL_ARRAY_BUFFER, colorbuffer[0]); // Bind the VBO colors for pyramid
	glBufferData (GL_ARRAY_BUFFER, sizeof(color_buffer_data), color_buffer_data, GL_STATIC_DRAW);  // Copy the vertex colors
	glVertexAttribPointer(
			1,                  // attribute 1. Color
			3,                  // size (r,g,b)
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);

}

void drawTop()
{
	glBindVertexArray (VertexArrayID[0]);
	
	// Enable Vertex Attribute 0 - 3d Vertices
	glEnableVertexAttribArray(0);
	// Bind the VBO to use
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[0]);

	// Enable Vertex Attribute 1 - Color
	glEnableVertexAttribArray(1);
	// Bind the VBO to use
	glBindBuffer(GL_ARRAY_BUFFER, colorbuffer[0]);

	// Draw the pyramid !
	glDrawArrays(GL_TRIANGLES, 0, numVerticesOfTop); // Starting from vertex 0; 3 vertices total -> 1 triangle

}

void createRectangle()
{
	static GLfloat vertex_buffer_data[60000];
	static GLfloat color_buffer_data[60000];
	int t = 0;
	printf("Yes\n");
	//for (int t = 1; t <= 150; t++)
	//{
		//printf("%d\n", t);
		int count = 0;
    	for(int i = -49; i < 50; i++)
    	{
    		for (int j = -49; j < 50; j++)
    		{
    			float l = i;
    			float m = j;
    			float k = polynomial(l/25, m/25);
    			color_buffer_data[count] = 0;
    			vertex_buffer_data[count++] = l/25;
    			color_buffer_data[count] = 0;
    			vertex_buffer_data[count++] = k;
    			color_buffer_data[count] = 1*fabs(k/4);
    			vertex_buffer_data[count++] = m/25;
    			color_buffer_data[count] = 0;
    			vertex_buffer_data[count++] = l/25;
    			color_buffer_data[count] = 0;
    			vertex_buffer_data[count++] = 0;
    			color_buffer_data[count] = 1;
    			vertex_buffer_data[count++] = m/25;
            	//if(l/9 > 0.1 && l/9 < 0.2)
    			printf("x = %f, y = %f, z = %f\n", l/100, k, m/100);
    		}
    	}
    	

		glBindVertexArray (VertexArrayID[1]); // Bind the VAO for cube

		glBindBuffer (GL_ARRAY_BUFFER, vertexbuffer[1]); // Bind the VBO vertices for cube
		glBufferData (GL_ARRAY_BUFFER, sizeof(vertex_buffer_data), vertex_buffer_data, GL_STATIC_DRAW);
		glVertexAttribPointer(
			0,                  // attribute 0. Vertices 
			3,                  // size (x,y,z)
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);

		glBindBuffer (GL_ARRAY_BUFFER, colorbuffer[1]); // Bind the VBO colors for cube
		glBufferData (GL_ARRAY_BUFFER, sizeof(color_buffer_data), color_buffer_data, GL_STATIC_DRAW);
		glVertexAttribPointer(
			1,                  // attribute 1. colors
			3,                  // size (r,g,b)
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);
	//}
}

void drawRectangle()
{
	
	// Bind the VAO to use
	glBindVertexArray (VertexArrayID[1]);

	// Enable Vertex Attribute 0 - 3d Vertices
	glEnableVertexAttribArray(0);
	// Bind the VBO to use
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[1]);

	// Enable Vertex Attribute 1 - Color
	glEnableVertexAttribArray(1);
	// Bind the VBO to use
	glBindBuffer(GL_ARRAY_BUFFER, colorbuffer[1]);

	// Draw the cube !
	glDrawArrays(GL_TRIANGLE_STRIP, 0, numVerticesOfCube); // Starting from vertex 0
}



glm::vec3 eye (8, 8, 0);
glm::vec3 target (0, 0, 0);
glm::vec3 up (0, 1, 0);


void keyboardSpecialDown (int key, int x, int y)
{
	if(key == GLUT_KEY_UP)
	{
		top_velocity_x += 0.1;
		top_velocity_z += 0.1;
		flag1 = 1;
	}
	if(key == GLUT_KEY_DOWN)
	{
		if(top_velocity_x != 0)
		top_velocity_x -= 0.1;
		if(top_velocity_z != 0)
		top_velocity_z -= 0.1;
		flag1 = 1;
	}
	if(key == GLUT_KEY_RIGHT)
	{
		if(theta >= 0)
			theta -= 0.1;
		flag2 = 1;
	}
	if(key == GLUT_KEY_LEFT)
	{
		if(theta <= pi)
			theta += 0.1;
		flag2 = 1;
	}
}

void keyboardDown (unsigned char key, int x, int y)
{
	//printf("%c\n", key);
	if(key == 13)
	{
		flag = 1;

	}

	else if(key == 't')
	{
		view = 1;


	}
}

void draw ()
{
	// clear the color and depth in the frame buffer
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// use the loaded shader program
	glUseProgram (programID);

	if(view == 1)
	{
		glm::vec3 temp1 (top_position_x, 1, top_position_z);
		glm::vec3 temp2 (0, 0, 0);
		glm::vec3 temp3 (1, 0, 0);
		eye = temp1;
		target = temp2;
		up = temp3;
	}
	

	// Compute Camera matrix (view)
	Matrices.view = glm::lookAt( eye, target, up );

	// Load identity to model matrix
	Matrices.model = glm::mat4(1.0f);

	// Compute ViewProject matrix as view/camera might not be changed for this frame (basic scenario)
	glm::mat4 VP = Matrices.projection * Matrices.view;
	
	// Send our transformation to the currently bound shader, in the "MVP" uniform
	// For each model you render, since the MVP will be different (at least the M part)
	glm::mat4 MVP;	// MVP = Projection * View * Model

	// Implement & use Push Matrix to save intermediate transformation matrices & reduce computations 
	// glPushMatrix ();

	/* Render your scene */

	glm::mat4 translatePyramid = glm::translate (glm::vec3(0.0f, 0.0f, 0.0f)); // glTranslatef
	glm::mat4 rotatePyramid = glm::rotate(rectangle_rotation, glm::vec3(1,0,0));  // glRotatef
	glm::mat4 scalePyramid = glm::scale(glm::mat4(1.0f), glm::vec3(2.0f));
	glm::mat4 pyramidTransform = translatePyramid * rotatePyramid * scalePyramid;
	Matrices.model *= pyramidTransform; 
	MVP = VP * Matrices.model; // MVP = p * V * M
	glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);

	drawRectangle();
	//drawTop();
	// Pop matrix to undo transformations till last push matrix instead of recomputing model matrix
	// glPopMatrix ();
	Matrices.model = glm::mat4(1.0f);
	glm::mat4 translateCube;
	glm::mat4 rotateCube;
	glm::mat4 scaleCube = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f));

	translateCube = glm::translate (glm::vec3(top_position_x, top_position_y/2, top_position_z));        // glTranslatef
	if(flag == 1)
	{
		
		rotateCube = glm::rotate(cube_rotation, glm::vec3(0,1,0)); // glRotatef
	}
	else
	{
		rotateCube = glm::mat4(1.0f);
		//drawTriangle();
	}
	Matrices.model *= (translateCube * rotateCube* scaleCube);
	MVP = VP * Matrices.model;
	glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);

	drawTop();

	// swap the frame buffers
	glutSwapBuffers ();

	// Increment angles
	camera_rotation_angle++;
	//rectangle_rotation++;
	cube_rotation += 0.2;

	//printf("%f %f\n", top_position_x, top_position_z);
	if(flag == 1)
	{
	if(top_position_x <= 5.0f && top_position_x >= -5.0f)
	{
		top_position_x += top_velocity_x* cos(theta);
		
	}
	else
	{
		top_velocity_x *= -1;
		top_position_x += top_velocity_x* cos(theta);
	}
	if(top_position_z <= 5.0f && top_position_z >= -5.0f)
	{
		top_position_z += top_velocity_z* sin(theta);
	}
	else
	{
		top_velocity_z *= -1;
		top_position_z += top_velocity_z*sin(theta);
	}
	top_position_y = polynomial(top_position_x/2, top_position_z/2);
}
}


/* Executed when the program is idle (no I/O activity) */
void idle () {
	// OpenGL should never stop drawing
	// can draw the same scene or a modified scene
	draw (); // drawing same scene
}


/* Initialise glut window, I/O callbacks and the renderer to use */
void initGLUT (int& argc, char** argv, int width, int height)
{
	// Init glut
	glutInit (&argc, argv);
	
	// Init glut window
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitContextVersion (3, 3); // Init GL 3.3
	glutInitContextFlags (GLUT_CORE_PROFILE); // Use Core profile - older functions are deprecated
	glutInitWindowSize (width, height);
	glutCreateWindow ("Top Shooter!");
	
	// Initialize GLEW, Needed in Core profile
	glewExperimental = GL_TRUE;
	GLenum err = glewInit();
	if (err != GLEW_OK) {
		cout << "Error: Failed to initialise GLEW : "<< glewGetErrorString(err) << endl;
		exit (1);
	}

	// register glut callbacks
	glutKeyboardFunc (keyboardDown);
	//glutKeyboardUpFunc (keyboardUp);

	glutSpecialFunc (keyboardSpecialDown);

	glutReshapeFunc (reshapeWindow);

	glutDisplayFunc (draw); // function to draw when active
	glutIdleFunc (idle); // function to draw when idle (no I/O activity)

	glutIgnoreKeyRepeat (true); // Ignore keys held down
}

/* Process menu option 'op' */
void menu(int op)
{
	switch(op)
	{
		case 'Q':
		case 'q':
			exit(0);
	}
}

void adddGLUTMenus ()
{
	// create sub menus
	int subMenu = glutCreateMenu (menu);
	glutAddMenuEntry ("Do Nothing", 0);
	glutAddMenuEntry ("Really Quit", 'q');

	// create main "right click" menu
	glutCreateMenu (menu);
	glutAddSubMenu ("Sub Menu", subMenu);
	glutAddMenuEntry ("Quit", 'q');
	glutAttachMenu (GLUT_RIGHT_BUTTON);
}



void initGL (int width, int height)
{
	// Create Vertex Array Object
	// Should be done after CreateWindow and before any other GL calls
	glGenVertexArrays(2, &VertexArrayID[0]); // VAO
	glGenBuffers (2, &vertexbuffer[0]); // VBO - vertices
	glGenBuffers (2, &colorbuffer[0]);  // VBO - colors
	
	// Create the models
	
	createRectangle();
	createTop();
	// Create and compile our GLSL program from the shaders
	programID = LoadShaders( "Sample_GL3.vert", "Sample_GL3.frag" );
	// Get a handle for our "MVP" uniform
	Matrices.MatrixID = glGetUniformLocation(programID, "MVP");

	
	reshapeWindow (width, height);

	glClearColor (0.0f, 0.0f, 0.0f, 0.0f);
	glClearDepth (1.0f);

	glEnable (GL_DEPTH_TEST);
	glDepthFunc (GL_LEQUAL);
}



int main (int argc, char** argv)
{
	int width = 800;
	int height = 600;

	initGLUT (argc, argv, width, height);

	adddGLUTMenus ();

	initGL (width, height);

	glutMainLoop ();

	return 0;
}
